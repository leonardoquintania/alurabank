#!/bin/sh
set -x
cd /usr/share/nginx/html/assets/config
JSON_FMT='{"path":"%s","port":%s}\n'
printf "$JSON_FMT" "$APIHOST" "$APIPORT" >appConfig.json

cd /usr/bin
nginx 