(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn-bd": "./node_modules/moment/locale/bn-bd.js",
	"./bn-bd.js": "./node_modules/moment/locale/bn-bd.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-in": "./node_modules/moment/locale/en-in.js",
	"./en-in.js": "./node_modules/moment/locale/en-in.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./en-sg": "./node_modules/moment/locale/en-sg.js",
	"./en-sg.js": "./node_modules/moment/locale/en-sg.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-mx": "./node_modules/moment/locale/es-mx.js",
	"./es-mx.js": "./node_modules/moment/locale/es-mx.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fil": "./node_modules/moment/locale/fil.js",
	"./fil.js": "./node_modules/moment/locale/fil.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-deva": "./node_modules/moment/locale/gom-deva.js",
	"./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
	"./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tk": "./node_modules/moment/locale/tk.js",
	"./tk.js": "./node_modules/moment/locale/tk.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-mo": "./node_modules/moment/locale/zh-mo.js",
	"./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/app/app-config.service.ts":
/*!***************************************!*\
  !*** ./src/app/app-config.service.ts ***!
  \***************************************/
/*! exports provided: AppConfigService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppConfigService", function() { return AppConfigService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");



class AppConfigService {
    constructor(http) {
        this.http = http;
    }
    loadAppConfig() {
        return this.http
            .get('/assets/config/appConfig.json')
            .toPromise()
            .then((data) => {
            this.appConfig = data;
        });
    }
    getConfig() {
        if (!this.appConfig.port) {
            return `${this.appConfig.path}/`;
        }
        return `${this.appConfig.path}:${this.appConfig.port}/`;
    }
}
AppConfigService.ɵfac = function AppConfigService_Factory(t) { return new (t || AppConfigService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"])); };
AppConfigService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AppConfigService, factory: AppConfigService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppConfigService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth/auth.guard */ "./src/app/auth/auth.guard.ts");
/* harmony import */ var _summary_chart_page_summary_chart_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./summary-chart-page/summary-chart-page */ "./src/app/summary-chart-page/summary-chart-page.ts");
/* harmony import */ var _detail_chart_page_detail_chart_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./detail-chart-page/detail-chart-page */ "./src/app/detail-chart-page/detail-chart-page.ts");









const routes = [
    { path: 'login', component: _login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"] },
    {
        path: 'home',
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_2__["HomeComponent"],
        canActivate: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["Authguard"]],
    },
    { path: 'compare', canActivate: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["Authguard"]], component: _summary_chart_page_summary_chart_page__WEBPACK_IMPORTED_MODULE_5__["SummaryChartPage"] },
    { path: 'status', canActivate: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_4__["Authguard"]], component: _detail_chart_page_detail_chart_page__WEBPACK_IMPORTED_MODULE_6__["DetailChartPage"] },
    { path: '', redirectTo: '/home', pathMatch: 'full' },
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
        _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]],
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");






function AppComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "po-toolbar", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "po-menu", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "router-outlet");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("p-menus", ctx_r0.menus);
} }
function AppComponent_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "router-outlet");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class AppComponent {
    constructor(appservice) {
        this.appservice = appservice;
        this.mostrarMenu = true;
        this.menus = [
            {
                label: 'Home',
                icon: 'po-icon po-icon-home',
                shortLabel: 'Home',
                link: '/home',
            },
            {
                label: 'Status testes',
                icon: 'po-icon po-icon-chart-columns',
                shortLabel: 'Status',
                link: '/status',
            },
            {
                label: 'Comparar testes',
                icon: 'po-icon po-icon-sale',
                shortLabel: 'Comparar',
                link: '/compare',
            },
        ];
    }
    ngOnInit() {
        this.appservice.mostrarMenuEmitter.subscribe((mostrar) => (this.mostrarMenu = mostrar));
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 3, vars: 2, consts: [["class", "po-wrapper", 4, "ngIf", "ngIfElse"], ["elseBlock", ""], [1, "po-wrapper"], ["p-title", "Portal da Qualidade"], ["p-collapsed", "", 3, "p-menus"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, AppComponent_div_0_Template, 4, 1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AppComponent_ng_template_1_Template, 2, 0, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.mostrarMenu)("ngIfElse", _r1);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_3__["PoToolbarComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_3__["PoMenuComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterOutlet"]], styles: [".divContent[_ngcontent-%COMP%] {\r\n  overflow: auto;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0FBQ2hCIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZGl2Q29udGVudCB7XHJcbiAgb3ZlcmZsb3c6IGF1dG87XHJcbn1cclxuIl19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.css'],
            }]
    }], function () { return [{ type: _app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _app_config_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-config.service */ "./src/app/app-config.service.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @po-ui/ng-templates */ "./node_modules/@po-ui/ng-templates/__ivy_ngcc__/fesm2015/po-ui-ng-templates.js");
/* harmony import */ var _summary_chart_page_summary_chart_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./summary-chart-page/summary-chart-page */ "./src/app/summary-chart-page/summary-chart-page.ts");
/* harmony import */ var _detail_chart_page_detail_chart_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./detail-chart-page/detail-chart-page */ "./src/app/detail-chart-page/detail-chart-page.ts");
/* harmony import */ var _filters_form_filters_form_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./filters-form/filters-form.component */ "./src/app/filters-form/filters-form.component.ts");
/* harmony import */ var _filters_compare_filters_compare_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./filters-compare/filters-compare.component */ "./src/app/filters-compare/filters-compare.component.ts");
/* harmony import */ var _chart_chart_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./chart/chart.component */ "./src/app/chart/chart.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./filters-form/filters-form.service */ "./src/app/filters-form/filters-form.service.ts");
/* harmony import */ var _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./filters-compare/filters-compare.service */ "./src/app/filters-compare/filters-compare.service.ts");
/* harmony import */ var _chart_chart_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./chart/chart.service */ "./src/app/chart/chart.service.ts");
/* harmony import */ var _detail_chart_page_detail_chart_page_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./detail-chart-page/detail-chart-page.service */ "./src/app/detail-chart-page/detail-chart-page.service.ts");























const appInitializerFn = (appConfig) => {
    return () => {
        return appConfig.loadAppConfig();
    };
};
class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [
        _app_config_service__WEBPACK_IMPORTED_MODULE_6__["AppConfigService"],
        {
            provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["APP_INITIALIZER"],
            useFactory: appInitializerFn,
            multi: true,
            deps: [_app_config_service__WEBPACK_IMPORTED_MODULE_6__["AppConfigService"]],
        },
        _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_17__["FiltersFormService"],
        _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_18__["FiltersCompareService"],
        _chart_chart_service__WEBPACK_IMPORTED_MODULE_19__["ChartService"],
        _detail_chart_page_detail_chart_page_service__WEBPACK_IMPORTED_MODULE_20__["DetailChartPageService"],
    ], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["BrowserAnimationsModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["NoopAnimationsModule"],
            _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoButtonModule"],
            _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__["PoPageLoginModule"],
            _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__["PoModalPasswordRecoveryModule"],
            _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoLoadingModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
            _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoModule"],
            _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoTableModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forRoot([]),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
        _login_login_component__WEBPACK_IMPORTED_MODULE_16__["LoginComponent"],
        _home_home_component__WEBPACK_IMPORTED_MODULE_15__["HomeComponent"],
        _summary_chart_page_summary_chart_page__WEBPACK_IMPORTED_MODULE_10__["SummaryChartPage"],
        _detail_chart_page_detail_chart_page__WEBPACK_IMPORTED_MODULE_11__["DetailChartPage"],
        _filters_form_filters_form_component__WEBPACK_IMPORTED_MODULE_12__["FiltersFormComponent"],
        _filters_compare_filters_compare_component__WEBPACK_IMPORTED_MODULE_13__["FiltersCompareComponent"],
        _chart_chart_component__WEBPACK_IMPORTED_MODULE_14__["ChartComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["BrowserAnimationsModule"],
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["NoopAnimationsModule"],
        _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoButtonModule"],
        _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__["PoPageLoginModule"],
        _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__["PoModalPasswordRecoveryModule"],
        _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoLoadingModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
        _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoModule"],
        _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoTableModule"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                    _login_login_component__WEBPACK_IMPORTED_MODULE_16__["LoginComponent"],
                    _home_home_component__WEBPACK_IMPORTED_MODULE_15__["HomeComponent"],
                    _summary_chart_page_summary_chart_page__WEBPACK_IMPORTED_MODULE_10__["SummaryChartPage"],
                    _detail_chart_page_detail_chart_page__WEBPACK_IMPORTED_MODULE_11__["DetailChartPage"],
                    _filters_form_filters_form_component__WEBPACK_IMPORTED_MODULE_12__["FiltersFormComponent"],
                    _filters_compare_filters_compare_component__WEBPACK_IMPORTED_MODULE_13__["FiltersCompareComponent"],
                    _chart_chart_component__WEBPACK_IMPORTED_MODULE_14__["ChartComponent"],
                ],
                imports: [
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                    _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["BrowserAnimationsModule"],
                    _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_7__["NoopAnimationsModule"],
                    _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoButtonModule"],
                    _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__["PoPageLoginModule"],
                    _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_9__["PoModalPasswordRecoveryModule"],
                    _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoLoadingModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                    _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoModule"],
                    _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_8__["PoTableModule"],
                    _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forRoot([]),
                ],
                providers: [
                    _app_config_service__WEBPACK_IMPORTED_MODULE_6__["AppConfigService"],
                    {
                        provide: _angular_core__WEBPACK_IMPORTED_MODULE_1__["APP_INITIALIZER"],
                        useFactory: appInitializerFn,
                        multi: true,
                        deps: [_app_config_service__WEBPACK_IMPORTED_MODULE_6__["AppConfigService"]],
                    },
                    _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_17__["FiltersFormService"],
                    _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_18__["FiltersCompareService"],
                    _chart_chart_service__WEBPACK_IMPORTED_MODULE_19__["ChartService"],
                    _detail_chart_page_detail_chart_page_service__WEBPACK_IMPORTED_MODULE_20__["DetailChartPageService"],
                ],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]],
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.service.ts":
/*!********************************!*\
  !*** ./src/app/app.service.ts ***!
  \********************************/
/*! exports provided: AppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppService", function() { return AppService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _class_Token__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./class/Token */ "./src/app/class/Token.ts");
/* harmony import */ var _app_config_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-config.service */ "./src/app/app-config.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");








class AppService {
    constructor(_http, configService, poNotification) {
        this._http = _http;
        this.configService = configService;
        this.poNotification = poNotification;
        this.userToken = new _class_Token__WEBPACK_IMPORTED_MODULE_3__["Token"]();
        this.mostrarMenuEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.URL_API = this.configService.getConfig();
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-type': 'application/json',
                Authorization: this.userToken.token || 'tokeninvalido',
            }),
        };
    }
    getToken(username, password) {
        //getToken(username, password): Observable<any> {
        /*return this._http
          .post<any>(
            this.URL_API + 'login.php',
            JSON.stringify({ User: username, Password: password }),
            this.httpOptions
          )
          .pipe(
            retry(3),
            map((res) => {
              console.log(res);
              this.userToken.token = res.Token;
              this.updateHeaders();
              sessionStorage.setItem('Token', this.userToken.token);
              sessionStorage.setItem('User', this.userToken.username);
              return this.userToken.token;
            }),
            catchError(this.handleError)
          );*/
        console.log(this.URL_API);
        this.mostrarMenuEmitter.emit(true);
        this.userToken.token = '123456789';
        this.updateHeaders();
        sessionStorage.setItem('Token', this.userToken.token);
        sessionStorage.setItem('User', this.userToken.username);
        return '123456789';
    }
    updateHeaders() {
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-type': 'application/json',
                Authorization: this.userToken.token,
            }),
        };
    }
    isLogged() {
        /* console.log(sessionStorage.getItem('Token'));
        console.log('------');
        console.log(!!sessionStorage.getItem('Token'));*/
        return !!sessionStorage.getItem('Token'); //Retorna se está logado.
    }
    handleError(err) {
        console.log(err);
        let serviceError = err.error;
        console.log(serviceError.Error);
        this.poNotification.error(serviceError.Error);
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])('Não foi possível concluir a solicitação');
    }
}
AppService.ɵfac = function AppService_Factory(t) { return new (t || AppService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_app_config_service__WEBPACK_IMPORTED_MODULE_4__["AppConfigService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoNotificationService"])); };
AppService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: AppService, factory: AppService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root',
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _app_config_service__WEBPACK_IMPORTED_MODULE_4__["AppConfigService"] }, { type: _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoNotificationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/auth/auth.guard.ts":
/*!************************************!*\
  !*** ./src/app/auth/auth.guard.ts ***!
  \************************************/
/*! exports provided: Authguard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Authguard", function() { return Authguard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_app_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/app.service */ "./src/app/app.service.ts");




class Authguard {
    constructor(router, instservice) {
        this.router = router;
        this.instservice = instservice;
    }
    canActivate(route, state) {
        return true;
    }
}
Authguard.ɵfac = function Authguard_Factory(t) { return new (t || Authguard)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](src_app_app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"])); };
Authguard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: Authguard, factory: Authguard.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Authguard, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{ providedIn: 'root' }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }, { type: src_app_app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/chart/chart.component.ts":
/*!******************************************!*\
  !*** ./src/app/chart/chart.component.ts ***!
  \******************************************/
/*! exports provided: ChartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChartComponent", function() { return ChartComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/dist/Chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _chart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./chart.service */ "./src/app/chart/chart.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");








const _c0 = ["modal"];
const _c1 = ["detailModal"];
const _c2 = ["pr_chart"];
function ChartComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "po-widget", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "canvas", 9, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ChartComponent_div_0_Template_canvas_click_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r6.handleChartClick($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const data_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](data_r4.options.title.text);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("id", data_r4.options.title.text);
} }
function ChartComponent_ng_template_7_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "po-widget");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "po-textarea", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function ChartComponent_ng_template_7_Template_po_textarea_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r11); const rowItem_r8 = ctx.$implicit; return rowItem_r8.OBSERV = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "po-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ChartComponent_ng_template_7_Template_po_button_click_4_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r11); const rowItem_r8 = ctx.$implicit; const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r12.errorAnalyze(rowItem_r8); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rowItem_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", rowItem_r8.OBSERV);
} }
const baseConfig = {
    type: 'line',
};
class ChartComponent {
    constructor(chartService) {
        this.chartService = chartService;
        this.close = {
            action: () => {
                this.closeModal();
            },
            label: 'Close',
            danger: true,
        };
        this.arraycsv = {
            action: () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield this.ArrayToCSV();
            }),
            label: 'Export CSV',
        };
    }
    closeModal() {
        if (this.chartService.titleModalDetail) {
            this.detailModal.close();
            this.chartService.titleModalDetail = '';
        }
        else {
            this.modal.close();
        }
    }
    ngOnDestroy() {
        this.chartService.parametersFilter = null;
    }
    ngOnInit() {
        this.chartService.actionsModal = [];
        this.chartService.actionsModal.push({
            action: this.openModalDetail.bind(this),
            icon: 'po-icon-info',
            label: 'Detalhes',
        });
    }
    openModalDetail(row) {
        this.chartService.openModalDetail(row);
        this.detailModal.open();
    }
    ngAfterViewInit() {
        this.chartElementRefs.changes.subscribe(() => {
            this.render();
        });
    }
    render() {
        this.chartElementRefs.map((chartElementRef, index) => {
            const config = Object.assign({}, baseConfig, this.chartService.chartData[index]);
            this.chartService.charts.push(new chart_js__WEBPACK_IMPORTED_MODULE_2__["Chart"](chartElementRef.nativeElement, config));
        });
    }
    handleChartClick(event) {
        const chartOfId = event.target.id;
        const chartSelected = this.chartService.charts.filter((chart) => chart.canvas.id === chartOfId)[0];
        const activePoint = chartSelected.getElementAtEvent(event);
        //-- Cria novo objeto sem a referencia do objeto principal
        this.chartService.parametersFilterDetails = JSON.parse(JSON.stringify(this.chartService.parametersFilter));
        if (activePoint.length > 0) {
            const dataset = chartSelected.data.datasets[activePoint[0]._datasetIndex];
            const title = chartSelected.data.labels[activePoint[0]._index];
            const value = dataset.data[activePoint[0]._index];
            console.log(this.chartService.parametersFilter.isTotvs);
            if (chartOfId !== 'TOTAL GERAL') {
                //-- Em caso de não ser Totvs, e for uma Suite de teste,
                //-- abrir direto os detalhes dos casos de testes
                if (!this.chartService.parametersFilter.isTotvs) {
                    const row = { TESTSUITE: chartOfId };
                    //-- Realiza filtro para trazer apenas o selecionado
                    this.chartService.parametersFilterDetails.dataGrid = this.chartService.parametersFilterDetails.dataGrid.filter((data) => data.country +
                        data.identifier +
                        data.release +
                        data.idExecution ===
                        title[0] + title[1] + title[2] + title[3]);
                    this.chartService.titleModal = title
                        .slice(0, 4)
                        .toString()
                        .replace(/,/g, '|');
                    this.openModalDetail(row);
                    return;
                }
                //-- Verificar qual visão está sendo usada
                switch (this.chartService.parametersFilterDetails.selectedTypeBlend) {
                    case 'segmento':
                        this.chartService.parametersFilterDetails.selectedSegment = new Array(chartOfId);
                        break;
                    case 'squad':
                        this.chartService.parametersFilterDetails.selectedSquad = new Array(chartOfId);
                        break;
                    case 'modulo':
                        this.chartService.parametersFilterDetails.selectedModule = new Array(chartOfId);
                        break;
                    case 'criticidade':
                        this.chartService.parametersFilterDetails.selectedCriticidade = new Array(chartOfId);
                        break;
                    default:
                        break;
                }
            }
            //-- Realiza filtro para trazer apenas o selecionado
            this.chartService.parametersFilterDetails.dataGrid = this.chartService.parametersFilterDetails.dataGrid.filter((data) => data.country + data.identifier + data.release + data.idExecution ===
                title[0] + title[1] + title[2] + title[3]);
            this.chartService.dataGridModal = [];
            this.chartService.titleModal = 'Processando...';
            this.chartService.isLoadingModal = true;
            this.chartService
                .processDataDetail(this.chartService.parametersFilterDetails)
                .subscribe((response) => {
                this.chartService.titleModal = title
                    .slice(0, 4)
                    .toString()
                    .replace(/,/g, '|');
                this.chartService.dataGridModal = response;
                this.chartService.isLoadingModal = false;
            });
            this.modal.open();
        }
    }
    errorAnalyze(row) {
        let body = { UNIQUEID: row.UNIQUEID, OBSERV: row.OBSERV }; //-- Mesclando o id da row com a observação
        let bodyString = JSON.stringify(body); //-- Transforma objeto em string.
        this.chartService.analyzeSalve(bodyString).subscribe((result) => {
            row.STATUS = '1';
            this.chartService.handleMessage('Registro atualizado com sucesso!');
        }, (error) => {
            this.chartService.handleMessage('Não foi possível atualizar o registro. Por favor verifique!', 3);
        });
    }
    ArrayToCSV() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const filename = 'automacao_advpr.csv';
            let csvHeader = '';
            //-- Configuração de colunas a serem exibidas
            if (this.chartService.parametersFilter.isTotvs) {
                csvHeader =
                    'Segmento;Squad;Módulo;Pais;Identificador;Release;Id Execução;Suite;TestCase;Método;Numero CT;Status;Tipo de Teste;Msg de Falha;Observação\n';
            }
            else {
                csvHeader =
                    'Pais;Identificador;Release;Id Execução;Suite;TestCase;Método;Numero CT;Status;Tipo de Teste;Msg de Falha;Observação\n';
            }
            let array = [];
            let csvData = '';
            this.chartService.isLoadingModal = true;
            yield this.chartService.processDetailCSV().subscribe((response) => {
                array = response;
                for (var i = 0; i < array.length; i++) {
                    if (this.chartService.parametersFilter.isTotvs) {
                        csvData += array[i].SEGMENTO + ';';
                        csvData += array[i].SQUAD + ';';
                        csvData += array[i].MODULO + ';';
                    }
                    csvData += array[i].COUNTRY + ';';
                    csvData += array[i].IDENTI + ';';
                    csvData += array[i].RELEASE + ';';
                    csvData += array[i].IDEXEC + ';';
                    csvData += array[i].TESTSUITE + ';';
                    csvData += array[i].TESTCASE + ';';
                    csvData += array[i].CTMETHOD + ';';
                    csvData += array[i].CTNUMBER + ';';
                    csvData += array[i].STATUS === '1' ? 'Analisado;' : 'Sem Analise;';
                    csvData +=
                        array[i].TESTTYPE === '1'
                            ? 'Integrado;'
                            : array[i].TESTTYPE === '2'
                                ? 'Unitário;'
                                : 'Processo;';
                    csvData += array[i].FAILMSG + ';';
                    csvData += array[i].OBSERV + ';';
                    csvData += '\n';
                }
                let csv = csvHeader + csvData;
                let data, link;
                csv = 'data:text/csv;charset=utf-8,%EF%BB%BF' + encodeURIComponent(csv);
                data = csv;
                link = document.createElement('a');
                link.setAttribute('href', data);
                link.setAttribute('download', filename);
                link.style.display = 'none';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                this.chartService.isLoadingModal = false;
            });
            return;
        });
    }
}
ChartComponent.ɵfac = function ChartComponent_Factory(t) { return new (t || ChartComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_chart_service__WEBPACK_IMPORTED_MODULE_3__["ChartService"])); };
ChartComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ChartComponent, selectors: [["app-chart"]], viewQuery: function ChartComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstaticViewQuery"](_c0, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstaticViewQuery"](_c1, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c2, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.modal = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.detailModal = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.chartElementRefs = _t);
    } }, decls: 8, vars: 18, consts: [["class", "po-text-center", 4, "ngFor", "ngForOf"], ["p-size", "auto", 3, "p-title", "p-primary-action", "p-secondary-action"], ["modal", ""], [3, "p-actions", "p-items", "p-columns", "p-loading", "p-height", "p-striped"], ["detailModal", ""], ["p-container", "", "p-sort", "true", "p-container", "shadow", 3, "p-striped", "p-columns", "p-items", "p-loading", "p-height"], ["p-table-row-template", ""], [1, "po-text-center"], [1, "po-lg-6", "po-mt-2"], [3, "id", "click"], ["pr_chart", ""], [1, "po-lg-12"], ["p-label", "Observa\u00E7\u00E3o", 3, "ngModel", "ngModelChange"], ["p-label", "Salvar", 3, "click"]], template: function ChartComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, ChartComponent_div_0_Template, 6, 2, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "po-modal", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "po-table", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "po-modal", 1, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "po-table", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, ChartComponent_ng_template_7_Template, 5, 1, "ng-template", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.chartService.chartData);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-title", ctx.chartService.titleModal)("p-primary-action", ctx.close)("p-secondary-action", ctx.arraycsv);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-actions", ctx.chartService.actionsModal)("p-items", ctx.chartService.dataGridModal)("p-columns", ctx.chartService.columnsGridModal)("p-loading", ctx.chartService.isLoadingModal)("p-height", 400)("p-striped", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-title", ctx.chartService.titleModalDetail)("p-primary-action", ctx.close)("p-secondary-action", ctx.arraycsv);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-striped", true)("p-columns", ctx.chartService.columnsGridModalDetail)("p-items", ctx.chartService.dataGridModalDetail)("p-loading", ctx.chartService.isLoadingModalDetail)("p-height", 400);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoModalComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoTableComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoTableRowTemplateDirective"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoWidgetComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoTextareaComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgModel"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoButtonComponent"]], encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](ChartComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"],
        args: [{
                selector: 'app-chart',
                templateUrl: './chart.component.html',
            }]
    }], function () { return [{ type: _chart_service__WEBPACK_IMPORTED_MODULE_3__["ChartService"] }]; }, { modal: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['modal', { static: true }]
        }], detailModal: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['detailModal', { static: true }]
        }], chartElementRefs: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"],
            args: ['pr_chart']
        }] }); })();


/***/ }),

/***/ "./src/app/chart/chart.service.ts":
/*!****************************************!*\
  !*** ./src/app/chart/chart.service.ts ***!
  \****************************************/
/*! exports provided: ChartService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChartService", function() { return ChartService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _app_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app-config.service */ "./src/app/app-config.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");







const httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' }),
};
class ChartService {
    constructor(_http, configService, poNotification) {
        this._http = _http;
        this.configService = configService;
        this.poNotification = poNotification;
        this.graphs = [];
        this.chartData = [];
        this.charts = [];
        this.isHideLoading = true;
        this.isLoadingModal = false;
        this.isLoadingModalDetail = false;
        this.columnsGridModal = [
            { property: 'TESTSUITE', label: 'Suíte de Teste', width: '800px' },
            {
                property: 'actions',
                label: '.',
                align: 'center',
                readonly: true,
                action: true,
            },
        ];
        this.columnsGridModalDetail = [
            { property: 'UNIQUEID', visible: false },
            {
                //-- (Sem Analise/Analisado)
                property: 'STATUS',
                label: 'Status',
                type: 'label',
                width: '100px',
                labels: [
                    { value: '', color: 'color-08', label: 'Sem análise' },
                    { value: '1', color: 'color-03', label: 'Analisado' },
                ],
            },
            { property: 'TESTCASE', label: 'Caso de Teste', width: '200px' },
            { property: 'CTMETHOD', label: 'Método CT', width: '130px' },
            { property: 'CTNUMBER', label: 'Número CT', width: '130px' },
            {
                //-- (Integrado/Unitario/Processo)
                property: 'TESTTYPE',
                label: 'Tipo Teste',
                type: 'label',
                width: '100px',
                labels: [
                    { value: '1', color: 'color-01', label: 'Integrado' },
                    { value: '2', color: 'color-09', label: 'Unitário' },
                    { value: '3', color: 'color-11', label: 'Processo' },
                ],
            },
            { property: 'FAILMSG', label: 'Descrição Falha', width: '200px' },
            { property: 'OBSERV', label: 'Observação', width: '200px' },
            { property: 'actions', label: '.', readonly: true, action: true },
        ];
        this.titleModal = '';
        this.titleModalDetail = '';
        this.actionsModal = [];
        this.URL_API = this.configService.getConfig();
    }
    //-- Realiza processamento dos graficos
    processData() {
        const { selectedTypeBlend: type, selectedSegment: segments, selectedSquad: squad, selectedModule: module, dataGrid: data, } = this.parametersFilter;
        let encodeData = encodeURIComponent(JSON.stringify(data));
        //-- Envio de parametros para consulta
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                TYPE: type,
                SEGMENT: segments,
                SQUAD: squad,
                MODULE: module,
                GRID: encodeData,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'log', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    processDataDetail(parametersFilter, TESTSUITE = '') {
        const { selectedTypeBlend: type, selectedSegment: segments, selectedSquad: squad, selectedModule: module, dataGrid: data, } = parametersFilter;
        let encodeData = encodeURIComponent(JSON.stringify(data));
        //-- Envio de parametros para consulta
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                TYPE: type,
                SEGMENT: segments,
                SQUAD: squad,
                MODULE: module,
                GRID: encodeData,
                TESTSUITE: TESTSUITE,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        if (TESTSUITE) {
            return this._http.get(this.URL_API + 'log-detail-suite', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
                console.log(res);
                return res;
            }));
        }
        else {
            return this._http.get(this.URL_API + 'log-detail', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
                console.log(res);
                return res;
            }));
        }
    }
    processDetailCSV() {
        const { selectedTypeBlend: type, selectedSegment: segments, selectedSquad: squad, selectedModule: module, dataGrid: data, } = this.parametersFilterDetails;
        let encodeData = encodeURIComponent(JSON.stringify(data));
        //-- Envio de parametros para consulta
        let params;
        if (this.titleModalDetail) {
            params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
                fromObject: {
                    TYPE: type,
                    SEGMENT: segments,
                    SQUAD: squad,
                    MODULE: module,
                    TESTSUITE: this.titleModalDetail,
                    GRID: encodeData,
                },
            });
        }
        else {
            params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
                fromObject: {
                    TYPE: type,
                    SEGMENT: segments,
                    SQUAD: squad,
                    MODULE: module,
                    GRID: encodeData,
                },
            });
        }
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'log-detail-complete', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            console.log(res);
            return res;
        }));
    }
    mountMultiplesCharts(graphs) {
        let chartData = [];
        if (graphs) {
            Object.keys(graphs).forEach((index) => {
                let templateLabel = [];
                let templateTotal = [];
                let templatePass = [];
                let templateFail = [];
                let templateTime = [];
                graphs[index].forEach((element) => {
                    //-- Efetua label de gráficos
                    const hoursMinutesSeconds = this.secondsToHms(element.SECONDS);
                    templateLabel.push([
                        element.COUNTRY,
                        element.IDENTI,
                        element.RELEASE,
                        element.IDEXEC,
                        hoursMinutesSeconds,
                    ]);
                    templateTotal.push(element.TOTAL);
                    templatePass.push(element.PASS);
                    templateFail.push(element.FAIL);
                    //templateTime.push(hoursMinutesSeconds);
                });
                const strLabels = JSON.stringify(templateLabel);
                let templateObj = `{
          "data": {
            "labels": ${strLabels},
            "datasets": [
              {
                "label": "Total",
                "data": [${templateTotal}],
                "backgroundColor": "#20B2AA",
                "borderColor": "#20B2AA",
                "fill": false,
                "cubicInterpolationMode": "monotone"

              },
              {
                "label": "Passou",
                "data": [${templatePass}],
                "backgroundColor": "#66CDAA",
                "borderColor": "#66CDAA",
                "fill": false,
                "cubicInterpolationMode": "monotone"
              },
              {
                "label": "Falhou",
                "data": [${templateFail}],
                "backgroundColor": "#FA8072",
                "borderColor": "#FA8072",
                "fill": false,
                "cubicInterpolationMode": "monotone"
              }
            ]
          },
          "options": {
            "title": {
                "display": false,
                "text": "${index}"
            },
            "legend": {
              "position": "bottom",
              "display": true,
              "fullWidth": true,
              "labels": {
                "fontSize": 12
              }
            }
          }

        }`;
                //-- Transforma string em objeto
                let obj = JSON.parse(templateObj);
                chartData.push(obj);
            });
            return chartData;
        }
    }
    secondsToHms(seconds) {
        const hour = Math.floor(seconds / 3600);
        const minute = Math.floor((seconds % 3600) / 60);
        const second = Math.floor((seconds % 3600) % 60);
        return `${hour}:${minute}:${second}`;
    }
    handleMessage(text, type = 1) {
        switch (type) {
            case 1:
                this.poNotification.success(text);
                break;
            case 2:
                this.poNotification.information(text);
                break;
            default:
                this.poNotification.error(text);
                break;
        }
    }
    analyzeSalve(data) {
        return this._http
            .put(`${this.URL_API}analyze-save`, data, httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    openModalDetail(row) {
        this.isLoadingModalDetail = true;
        this.titleModalDetail = 'Processando...';
        this.dataGridModalDetail = [];
        this.processDataDetail(this.parametersFilterDetails, row.TESTSUITE).subscribe((response) => {
            console.log(response);
            this.titleModalDetail = row.TESTSUITE;
            this.dataGridModalDetail = response;
            this.isLoadingModalDetail = false;
        });
    }
}
ChartService.ɵfac = function ChartService_Factory(t) { return new (t || ChartService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoNotificationService"])); };
ChartService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: ChartService, factory: ChartService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ChartService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"] }, { type: _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoNotificationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/class/Token.ts":
/*!********************************!*\
  !*** ./src/app/class/Token.ts ***!
  \********************************/
/*! exports provided: Token */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Token", function() { return Token; });
class Token {
}


/***/ }),

/***/ "./src/app/detail-chart-page/detail-chart-page.service.ts":
/*!****************************************************************!*\
  !*** ./src/app/detail-chart-page/detail-chart-page.service.ts ***!
  \****************************************************************/
/*! exports provided: DetailChartPageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailChartPageService", function() { return DetailChartPageService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! chart.js */ "./node_modules/chart.js/dist/Chart.js");
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(chart_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _app_config_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../app-config.service */ "./src/app/app-config.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");








const httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({ 'Content-Type': 'application/json' }),
};
class DetailChartPageService {
    constructor(_http, configService, poNotification) {
        this._http = _http;
        this.configService = configService;
        this.poNotification = poNotification;
        this.URL_API = this.configService.getConfig();
    }
    getFromIdExecution(country, identifier, release, idexecution) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                COUNTRY: country,
                IDENTI: identifier,
                RELEASE: release,
                IDEXEC: idexecution,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'getFromIdExecution', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    //--Consulta database e extrai as informações
    getFromIdAnalyze(country, identifier, release, idexecution) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                COUNTRY: country,
                IDENTI: identifier,
                RELEASE: release,
                IDEXEC: idexecution,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'getFromIdAnalyze', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    //--Consulta database e extrai as informações
    getFromIdTestSuite(country, identifier, release, idexecution, testSuite) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                COUNTRY: country,
                IDENTI: identifier,
                RELEASE: release,
                IDEXEC: idexecution,
                TESTSUITE: testSuite,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'getFromIdTestSuite', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    getFromAllTestSuite(country, identifier, release, idexecution) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                COUNTRY: country,
                IDENTI: identifier,
                RELEASE: release,
                IDEXEC: idexecution,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'getFromAllTestSuite', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    //--Monta string  do gráfico
    chartFromIdExecution(results) {
        const { PASS, FAIL, IDEXEC } = results[0];
        return new chart_js__WEBPACK_IMPORTED_MODULE_3__["Chart"]('resultado', {
            type: 'doughnut',
            data: {
                labels: ['Passou', 'Falhou'],
                datasets: [
                    {
                        label: IDEXEC,
                        data: [PASS, FAIL],
                        backgroundColor: ['#66CDAA', '#FA8072'],
                    },
                ],
            },
            options: {
                title: {
                    display: true,
                    text: 'Status Geral',
                },
                legend: {
                    position: 'bottom',
                    display: true,
                    fullWidth: true,
                    labels: {
                        fontSize: 12,
                    },
                },
                scales: {
                    xAxes: [
                        {
                            display: false,
                        },
                    ],
                    yAxes: [
                        {
                            display: false,
                        },
                    ],
                },
            },
        });
    }
    chartFromIdAnalyze(results) {
        const analyzed = results.filter((result) => result.STATUS === 'ANALISADO')[0];
        const withoutAnalyze = results.filter((result) => result.STATUS === 'SEM ANALISE')[0];
        return new chart_js__WEBPACK_IMPORTED_MODULE_3__["Chart"]('andamento', {
            type: 'doughnut',
            data: {
                labels: ['Analisado', 'Sem Análise'],
                datasets: [
                    {
                        label: results[0].IDEXEC,
                        data: [analyzed.FAILTOTAL, withoutAnalyze.FAILTOTAL],
                        backgroundColor: ['#20B2AA', '#F0E68C'],
                    },
                ],
            },
            options: {
                title: {
                    display: true,
                    text: 'Status X Falhas',
                },
                legend: {
                    position: 'bottom',
                    display: true,
                    fullWidth: true,
                    labels: {
                        fontSize: 12,
                    },
                },
                scales: {
                    xAxes: [
                        {
                            display: false,
                        },
                    ],
                    yAxes: [
                        {
                            display: false,
                        },
                    ],
                },
            },
        });
    }
    chartFromIdTestSuite(results) {
        const maxValue = Math.max(...results.mappedTestSuitePass, ...results.mappedTestSuiteFail);
        return new chart_js__WEBPACK_IMPORTED_MODULE_3__["Chart"]('suite', {
            type: 'bar',
            data: {
                labels: results.mappedTestSuiteName,
                datasets: [
                    {
                        label: 'Total',
                        data: results.mappedTestSuiteTotal,
                        backgroundColor: '#20B2AA',
                    },
                    {
                        label: 'Passou',
                        data: results.mappedTestSuitePass,
                        backgroundColor: '#66CDAA',
                    },
                    {
                        label: 'Falhou',
                        data: results.mappedTestSuiteFail,
                        backgroundColor: '#FA8072',
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                title: {
                    text: 'Status X Suite',
                    display: true,
                },
                legend: {
                    position: 'bottom',
                    display: true,
                    fullWidth: true,
                    labels: {
                        fontSize: 12,
                    },
                },
                scales: {
                    yAxes: [
                        {
                            ticks: {
                                autoSkip: true,
                                beginAtZero: true,
                                min: 0,
                                max: maxValue,
                            },
                        },
                    ],
                },
            },
        });
    }
    //--Consulta database e extrai as informações
    getFromLogAll(country, identifier, release, idexecution, testSuite) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: {
                COUNTRY: country,
                IDENTI: identifier,
                RELEASE: release,
                IDEXEC: idexecution,
                TESTSUITE: testSuite,
            },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        console.log(options);
        return this._http.get(this.URL_API + 'getFromLogAll', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    analyzeSalve(data) {
        return this._http
            .put(`${this.URL_API}analyze-save`, data, httpOptions)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    handleMessage(text, type) {
        switch (type) {
            case 1:
                this.poNotification.success(text);
                break;
            case 2:
                this.poNotification.information(text);
                break;
            case 3:
                this.poNotification.warning(text);
                break;
            default:
                this.poNotification.error(text);
                break;
        }
    }
    ArrayToCSV(country, identifier, release, idexecution, testSuite) {
        const filename = 'automacao_advpr.csv';
        //-- Configuração de colunas a serem exibidas
        const csvHeader = 'Pais;Identificador;Release;Id Execução;Suite;TestCase;Método;Numero CT;Status;Tipo de Teste;Msg de Falha;Observação\n';
        let array = [];
        let csvData = '';
        this.getFromLogAll(country, identifier, release, idexecution, testSuite).subscribe((response) => {
            array = response;
            for (var i = 0; i < array.length; i++) {
                csvData += array[i].COUNTRY + ';';
                csvData += array[i].IDENTI + ';';
                csvData += array[i].RELEASE + ';';
                csvData += array[i].IDEXEC + ';';
                csvData += array[i].TESTSUITE + ';';
                csvData += array[i].TESTCASE + ';';
                csvData += array[i].CTMETHOD + ';';
                csvData += array[i].CTNUMBER + ';';
                csvData += array[i].STATUS === '1' ? 'Analisado;' : 'Sem Analise;';
                csvData +=
                    array[i].TESTTYPE === '1'
                        ? 'Integrado;'
                        : array[i].TESTTYPE === '2'
                            ? 'Unitário;'
                            : 'Processo;';
                csvData += array[i].FAILMSG + ';';
                csvData += array[i].OBSERV + ';';
                csvData += '\n';
            }
            let csv = csvHeader + csvData;
            let data, link;
            csv = 'data:text/csv;charset=utf-8,%EF%BB%BF' + encodeURIComponent(csv);
            data = csv;
            link = document.createElement('a');
            link.setAttribute('href', data);
            link.setAttribute('download', filename);
            link.style.display = 'none';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
        return;
    }
}
DetailChartPageService.ɵfac = function DetailChartPageService_Factory(t) { return new (t || DetailChartPageService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_app_config_service__WEBPACK_IMPORTED_MODULE_4__["AppConfigService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoNotificationService"])); };
DetailChartPageService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: DetailChartPageService, factory: DetailChartPageService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DetailChartPageService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _app_config_service__WEBPACK_IMPORTED_MODULE_4__["AppConfigService"] }, { type: _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoNotificationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/detail-chart-page/detail-chart-page.ts":
/*!********************************************************!*\
  !*** ./src/app/detail-chart-page/detail-chart-page.ts ***!
  \********************************************************/
/*! exports provided: DetailChartPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailChartPage", function() { return DetailChartPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../filters-compare/filters-compare.service */ "./src/app/filters-compare/filters-compare.service.ts");
/* harmony import */ var _detail_chart_page_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-chart-page.service */ "./src/app/detail-chart-page/detail-chart-page.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");








const _c0 = ["detailModal"];
const _c1 = ["item1"];
const _c2 = ["item2"];
function DetailChartPage_ng_template_26_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "po-widget");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "po-textarea", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetailChartPage_ng_template_26_Template_po_textarea_ngModelChange_2_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r7); const rowItem_r4 = ctx.$implicit; return rowItem_r4.OBSERV = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "po-button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DetailChartPage_ng_template_26_Template_po_button_click_3_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r7); const rowItem_r4 = ctx.$implicit; const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r8.analyze(rowItem_r4); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rowItem_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", rowItem_r4.OBSERV);
} }
const _c3 = function (a0) { return { width: a0, height: "400px" }; };
class DetailChartPage {
    constructor(filterService, detailChartService) {
        this.filterService = filterService;
        this.detailChartService = detailChartService;
        this.selectedCountry = 'BRA';
        this.selectedIdentifier = '';
        this.selectedRelease = '';
        this.selectedIdExecution = '';
        this.selectedTestSuite = [];
        this.country = [];
        this.identifier = [];
        this.release = [];
        this.idExecution = [];
        this.testSuite = [];
        this.isHideLoading = false;
        this.isLoadingModal = true;
        this.testSuiteSelected = '';
        this.columns = [
            { property: 'UNIQUEID', visible: false },
            {
                //-- (Sem Analise/Analisado)
                property: 'STATUS',
                label: 'Status',
                type: 'label',
                width: '100px',
                labels: [
                    { value: '', color: 'color-08', label: 'Sem análise' },
                    { value: '1', color: 'color-03', label: 'Analisado' },
                ],
            },
            { property: 'TESTCASE', label: 'Caso de Teste', width: '200px' },
            { property: 'CTMETHOD', label: 'Método CT', width: '130px' },
            { property: 'CTNUMBER', label: 'Número CT', width: '130px' },
            {
                //-- (Integrado/Unitario/Processo)
                property: 'TESTTYPE',
                label: 'Tipo Teste',
                type: 'label',
                width: '100px',
                labels: [
                    { value: '1', color: 'color-01', label: 'Integrado' },
                    { value: '2', color: 'color-09', label: 'Unitário' },
                    { value: '3', color: 'color-11', label: 'Processo' },
                ],
            },
            { property: 'FAILMSG', label: 'Descrição Falha', width: '200px' },
            { property: 'OBSERV', label: 'Observação', width: '200px' },
            { property: 'actions', label: '.', readonly: true, action: true },
        ];
        this.data = [];
        this.chartNumber = 0;
        this.responsive = 0;
        this.close = {
            action: () => {
                this.detailModal.close();
            },
            label: 'Close',
            danger: true,
        };
        this.arraycsv = {
            action: () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield this.ArrayToCSV();
            }),
            label: 'Export CSV',
        };
    }
    ngAfterContentInit() {
        this.item1.expand();
        this.item2.expand();
    }
    ngOnInit() {
        //-- Carga nos países
        this.getCountry();
    }
    getCountry() {
        //-- Efetua carga no segmento
        this.filterService.getCountry().subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.country = yield response;
        }), (error) => {
            console.log(error);
        });
    }
    getIdentifier() {
        //-- Zera variaveis para consulta de outro pais
        this.isHideLoading = false;
        this.selectedIdentifier = '';
        this.selectedRelease = '';
        this.selectedIdExecution = '';
        this.idExecution = [];
        this.release = [];
        //-- Efetua carga no segmento
        if (this.selectedCountry) {
            this.filterService
                .getIdentifier(this.selectedCountry)
                .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.identifier = yield response;
                this.selectedIdentifier = response[0].value;
                this.getRelease();
            }));
        }
        else {
            this.identifier = [];
            this.release = [];
            this.idExecution = [];
        }
    }
    getRelease() {
        this.isHideLoading = false;
        this.selectedRelease = '';
        this.selectedIdExecution = '';
        this.idExecution = [];
        //-- Efetua carga no segmento
        if (this.selectedIdentifier) {
            this.filterService
                .getRelease(this.selectedCountry, this.selectedIdentifier)
                .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.release = yield response;
                this.selectedRelease = response[0].value;
                this.getIdExecution();
            }));
        }
        else {
            this.release = [];
            this.idExecution = [];
        }
    }
    getIdExecution() {
        this.isHideLoading = false;
        this.selectedIdExecution = '';
        //-- Efetua carga no segmento
        if (this.selectedRelease) {
            this.filterService
                .getIdExecution(this.selectedCountry, this.selectedIdentifier, this.selectedRelease)
                .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.idExecution = yield response;
                this.selectedIdExecution = response[0].value;
                yield this.chartChanges();
            }));
        }
        else {
            this.idExecution = [];
        }
    }
    chartChanges() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //-- Carrega informações dos gráficos
            this.chartFromIdExecution(); //-- Gráfico resultado geral passou/falhou
            this.chartFromIdAnalyze(); //-- Gráfico de quanto foi Analisado/Sem Analise
            yield this.chartFromIdTestSuite(); //-- Gráfico de Barra por TestSuite
        });
    }
    chartFromIdExecution() {
        this.detailChartService
            .getFromIdExecution(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution)
            .subscribe((response) => {
            if (this.chartResultado) {
                this.chartResultado.destroy();
            }
            this.chartResultado = this.detailChartService.chartFromIdExecution(response);
        });
    }
    chartFromIdAnalyze() {
        this.detailChartService
            .getFromIdAnalyze(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution)
            .subscribe((response) => {
            if (this.chartAndamento) {
                this.chartAndamento.destroy();
            }
            this.chartAndamento = this.detailChartService.chartFromIdAnalyze(response);
        });
    }
    chartFromIdTestSuite() {
        this.detailChartService
            .getFromIdTestSuite(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution, this.selectedTestSuite)
            .subscribe((response) => {
            if (this.chartSuite) {
                this.chartSuite.destroy();
            }
            this.chartSuite = this.detailChartService.chartFromIdTestSuite(response);
            this.chartNumber = response.mappedTestSuiteName.length;
            this.responsive =
                this.chartNumber > 10
                    ? (this.responsive = this.chartNumber * 210)
                    : (this.responsive = 2000);
            //--Load na seleção de suites
            this.getFromAllTestSuite();
            this.isHideLoading = true;
        });
    }
    getFromAllTestSuite() {
        this.detailChartService
            .getFromAllTestSuite(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution)
            .subscribe((response) => {
            this.testSuite = response;
        });
    }
    gridFromLogAll() {
        this.detailChartService
            .getFromLogAll(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution, this.selectedTestSuite)
            .subscribe((response) => {
            this.data = response;
            this.isHideLoading = true;
        });
    }
    handleChartClick(event) {
        const activePoint = this.chartSuite.getElementAtEvent(event);
        if (activePoint.length > 0) {
            const dataset = this.chartSuite.data.datasets[activePoint[0]._datasetIndex];
            this.testSuiteSelected = this.chartSuite.data.labels[activePoint[0]._index];
            if (dataset.label === 'Falhou') {
                //-- Zera variaveis
                this.data = [];
                this.isLoadingModal = true;
                this.detailChartService
                    .getFromLogAll(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution, this.testSuiteSelected)
                    .subscribe((response) => {
                    this.data = response;
                    this.isLoadingModal = false;
                });
                this.detailModal.open();
            }
            else {
                this.detailChartService.handleMessage('Não foram encontradas execuções com falha, selecione outro.', 3);
            }
        }
    }
    ArrayToCSV() {
        this.detailChartService.ArrayToCSV(this.selectedCountry, this.selectedIdentifier, this.selectedRelease, this.selectedIdExecution, this.testSuiteSelected);
    }
    analyze(row) {
        let body = { UNIQUEID: row.UNIQUEID, OBSERV: row.OBSERV }; //-- Mesclando o id da row com a observação
        let bodyString = JSON.stringify(body); //-- Transforma objeto em string.
        this.detailChartService.analyzeSalve(bodyString).subscribe((result) => {
            row.STATUS = '1';
            this.detailChartService.handleMessage('Registro atualizado com sucesso!', 1);
        }, (error) => {
            this.detailChartService.handleMessage('Não foi possível atualizar o registro. Por favor verifique!', 3);
        });
        console.log(row);
    }
}
DetailChartPage.ɵfac = function DetailChartPage_Factory(t) { return new (t || DetailChartPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__["FiltersCompareService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_detail_chart_page_service__WEBPACK_IMPORTED_MODULE_3__["DetailChartPageService"])); };
DetailChartPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DetailChartPage, selectors: [["detail-chart-page"]], viewQuery: function DetailChartPage_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstaticViewQuery"](_c0, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstaticViewQuery"](_c1, true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstaticViewQuery"](_c2, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.detailModal = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.item1 = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.item2 = _t.first);
    } }, decls: 27, vars: 21, consts: [[3, "hidden"], ["p-title", "Status dos Testes"], ["p-label", "Filtros"], ["item1", ""], ["name", "selectedCountry", "p-label", "Pa\u00EDs", 1, "po-md-3", 3, "p-options", "ngModel", "ngModelChange", "p-change"], ["name", "selectedIdentifier", "p-label", "Identificador", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["name", "selectedRelease", "p-label", "Release", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["name", "selectedIdExecution", "p-label", "ID Execu\u00E7\u00E3o", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["p-label", "Status"], ["item2", ""], [1, "po-lg-6", "po-mt-2"], ["id", "resultado"], ["id", "andamento"], ["name", "selectedTestSuite", "p-placeholder", "Somente com falha(s) Limitado a 70 Su\u00EDtes", "p-label", "Su\u00EDte", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], [1, "po-lg-12", "po-mt-2"], [1, "chartContent"], [3, "ngStyle"], ["id", "suite", 3, "click"], ["p-size", "auto", 3, "p-title", "p-primary-action", "p-secondary-action"], ["detailModal", ""], ["p-container", "", "p-sort", "true", "p-height", "400", "p-container", "shadow", 3, "p-striped", "p-columns", "p-items", "p-loading"], ["p-table-row-template", ""], [1, "po-lg-12"], ["p-label", "Observa\u00E7\u00E3o", 3, "ngModel", "ngModelChange"], ["p-label", "Salvar", 3, "click"]], template: function DetailChartPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "po-loading-overlay", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "po-page-default", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "po-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "po-accordion-item", 2, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "po-select", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetailChartPage_Template_po_select_ngModelChange_6_listener($event) { return ctx.selectedCountry = $event; })("p-change", function DetailChartPage_Template_po_select_p_change_6_listener() { return ctx.getIdentifier(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "po-select", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetailChartPage_Template_po_select_ngModelChange_7_listener($event) { return ctx.selectedIdentifier = $event; })("p-change", function DetailChartPage_Template_po_select_p_change_7_listener() { return ctx.getRelease(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "po-select", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetailChartPage_Template_po_select_ngModelChange_8_listener($event) { return ctx.selectedRelease = $event; })("p-change", function DetailChartPage_Template_po_select_p_change_8_listener() { return ctx.getIdExecution(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "po-select", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetailChartPage_Template_po_select_ngModelChange_9_listener($event) { return ctx.selectedIdExecution = $event; })("p-change", function DetailChartPage_Template_po_select_p_change_9_listener() { return ctx.chartChanges(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "po-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "po-accordion-item", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "po-widget", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](14, "canvas", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "po-widget", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "canvas", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "po-multiselect", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetailChartPage_Template_po_multiselect_ngModelChange_18_listener($event) { return ctx.selectedTestSuite = $event; })("p-change", function DetailChartPage_Template_po_multiselect_p_change_18_listener() { return ctx.chartFromIdTestSuite(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "po-widget", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "canvas", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DetailChartPage_Template_canvas_click_22_listener($event) { return ctx.handleChartClick($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "po-modal", 18, 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "po-table", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](26, DetailChartPage_ng_template_26_Template, 4, 1, "ng-template", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("hidden", ctx.isHideLoading);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-options", ctx.country)("ngModel", ctx.selectedCountry);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selectedIdentifier)("p-options", ctx.identifier);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selectedRelease)("p-options", ctx.release);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selectedIdExecution)("p-options", ctx.idExecution);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selectedTestSuite)("p-options", ctx.testSuite);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](19, _c3, ctx.responsive + "px"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-title", ctx.testSuiteSelected)("p-primary-action", ctx.close)("p-secondary-action", ctx.arraycsv);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("p-striped", true)("p-columns", ctx.columns)("p-items", ctx.data)("p-loading", ctx.isLoadingModal);
    } }, directives: [_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoLoadingOverlayComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoPageDefaultComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoAccordionComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoAccordionItemComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoWidgetComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoMultiselectComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgStyle"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoModalComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoTableComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoTableRowTemplateDirective"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoTextareaComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoButtonComponent"]], styles: [".chartContent[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  overflow-x: scroll;\r\n  overflow-y: hidden;\r\n}\r\n\r\n.chartArea[_ngcontent-%COMP%] {\r\n  width: 2000px;\r\n  height: 400px;\r\n}\r\n\r\n.chartDefault[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  overflow-x: scroll;\r\n  overflow-y: hidden;\r\n}\r\n\r\n.chartAreaDefault[_ngcontent-%COMP%] {\r\n  width: 2000px;\r\n  height: 400px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV0YWlsLWNoYXJ0LXBhZ2UvZGV0YWlsLWNoYXJ0LXBhZ2UuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsYUFBYTtBQUNmOztBQUVBO0VBQ0UsV0FBVztFQUNYLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsYUFBYTtBQUNmIiwiZmlsZSI6InNyYy9hcHAvZGV0YWlsLWNoYXJ0LXBhZ2UvZGV0YWlsLWNoYXJ0LXBhZ2UuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNoYXJ0Q29udGVudCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgb3ZlcmZsb3cteDogc2Nyb2xsO1xyXG4gIG92ZXJmbG93LXk6IGhpZGRlbjtcclxufVxyXG5cclxuLmNoYXJ0QXJlYSB7XHJcbiAgd2lkdGg6IDIwMDBweDtcclxuICBoZWlnaHQ6IDQwMHB4O1xyXG59XHJcblxyXG4uY2hhcnREZWZhdWx0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBvdmVyZmxvdy14OiBzY3JvbGw7XHJcbiAgb3ZlcmZsb3cteTogaGlkZGVuO1xyXG59XHJcblxyXG4uY2hhcnRBcmVhRGVmYXVsdCB7XHJcbiAgd2lkdGg6IDIwMDBweDtcclxuICBoZWlnaHQ6IDQwMHB4O1xyXG59XHJcbiJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](DetailChartPage, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"],
        args: [{
                selector: 'detail-chart-page',
                templateUrl: './detail-chart-page.html',
                styleUrls: ['./detail-chart-page.css'],
            }]
    }], function () { return [{ type: _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__["FiltersCompareService"] }, { type: _detail_chart_page_service__WEBPACK_IMPORTED_MODULE_3__["DetailChartPageService"] }]; }, { detailModal: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['detailModal', { static: true }]
        }], item1: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['item1', { static: true }]
        }], item2: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
            args: ['item2', { static: true }]
        }] }); })();


/***/ }),

/***/ "./src/app/filters-compare/filters-compare.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/filters-compare/filters-compare.component.ts ***!
  \**************************************************************/
/*! exports provided: FiltersCompareComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiltersCompareComponent", function() { return FiltersCompareComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../filters-form/filters-form.service */ "./src/app/filters-form/filters-form.service.ts");
/* harmony import */ var _filters_compare_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./filters-compare.service */ "./src/app/filters-compare/filters-compare.service.ts");
/* harmony import */ var _chart_chart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../chart/chart.service */ "./src/app/chart/chart.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");







const _c0 = ["item1"];
class FiltersCompareComponent {
    constructor(filterFormService, filterService, chartService) {
        this.filterFormService = filterFormService;
        this.filterService = filterService;
        this.chartService = chartService;
        this.country = [];
        this.identifier = [];
        this.release = [];
        this.idExecution = [];
    }
    ngOnInit() {
        this.getCountry();
    }
    ngAfterContentInit() {
        this.item1.expand();
    }
    getCountry() {
        //-- Efetua carga no segmento
        this.filterService.getCountry().subscribe((response) => {
            this.country = response;
        }, (error) => {
            console.log(error);
        });
    }
    getIdentifier() {
        //-- Zera variaveis para consulta de outro pais
        this.filterService.selectedIdentifier = '';
        this.filterService.selectedRelease = '';
        this.filterService.selectedIdExecution = [];
        this.idExecution = [];
        this.release = [];
        //-- Efetua carga no segmento
        if (this.filterService.selectedCountry) {
            this.filterService
                .getIdentifier(this.filterService.selectedCountry)
                .subscribe((response) => {
                this.identifier = response;
            });
        }
        else {
            this.identifier = [];
            this.release = [];
            this.idExecution = [];
        }
    }
    getRelease() {
        this.filterService.selectedRelease = '';
        this.filterService.selectedIdExecution = [];
        this.idExecution = [];
        //-- Efetua carga no segmento
        if (this.filterService.selectedIdentifier) {
            this.filterService
                .getRelease(this.filterService.selectedCountry, this.filterService.selectedIdentifier)
                .subscribe((response) => {
                this.release = response;
            });
        }
        else {
            this.release = [];
            this.idExecution = [];
        }
    }
    getIdExecution() {
        this.filterService.selectedIdExecution = [];
        //-- Efetua carga no segmento
        if (this.filterService.selectedRelease) {
            this.filterService
                .getIdExecution(this.filterService.selectedCountry, this.filterService.selectedIdentifier, this.filterService.selectedRelease)
                .subscribe((response) => {
                this.idExecution = response;
            });
        }
        else {
            this.idExecution = [];
        }
    }
    processData() {
        if (this.filterService.dataGrid.length > 1) {
            this.chartService.parametersFilter = {
                selectedTypeBlend: this.filterFormService.selectedTypeBlend,
                selectedSegment: this.filterFormService.selectedSegment,
                selectedSquad: this.filterFormService.selectedSquad,
                selectedModule: this.filterFormService.selectedModule,
                isTotvs: this.filterFormService.isTotvs,
                selectedCountry: this.filterService.selectedCountry,
                selectedIdentifier: this.filterService.selectedIdentifier,
                selectedRelease: this.filterService.selectedRelease,
                selectedIdExecution: this.filterService.selectedIdExecution,
                lastExecution: this.filterService.lastExecution,
                dataGrid: this.filterService.dataGrid,
            };
            this.chartService.isHideLoading = false;
            //-- Processa os filtros selecionados
            this.chartService.processData().subscribe((response) => {
                this.chartService.graphs = response;
                this.chartService.charts = [];
                this.chartService.chartData = [];
                this.chartService.chartData = this.chartService.mountMultiplesCharts(this.chartService.graphs);
                this.chartService.isHideLoading = true;
            });
            this.item1.collapse();
        }
        else {
            this.filterService.handleMessage('Para a execução do filtro, é necessario no mínimo 2 IDs para comparação.', 2);
        }
    }
}
FiltersCompareComponent.ɵfac = function FiltersCompareComponent_Factory(t) { return new (t || FiltersCompareComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_1__["FiltersFormService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__["FiltersCompareService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_chart_chart_service__WEBPACK_IMPORTED_MODULE_3__["ChartService"])); };
FiltersCompareComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FiltersCompareComponent, selectors: [["filters-compare"]], viewQuery: function FiltersCompareComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_c0, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.item1 = _t.first);
    } }, decls: 12, vars: 12, consts: [["p-label", "Comparar"], ["item1", ""], ["name", "selectedCountry", "p-label", "Pa\u00EDs", 1, "po-md-3", 3, "p-options", "ngModel", "ngModelChange", "p-change"], ["name", "selectedIdentifier", "p-label", "Identificador", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["name", "selectedRelease", "p-label", "Release", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["name", "selectedIdExecution", "p-label", "ID Execu\u00E7\u00E3o", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange"], ["p-placeholder", "Todos", "name", "lastExecution", "p-label", "\u00DAltima Execu\u00E7\u00E3o?", 1, "po-md-12", 3, "ngModel", "ngModelChange"], ["p-label", "Adicionar", 1, "po-md-2", "po-offset-md-10", "po-offset-lg-10", "po-offset-xl-10", 3, "p-click"], [1, "po-xl-12", 3, "p-columns", "p-items"], [1, "po-row"], ["p-label", "Comparar", 1, "po-md-2", "po-offset-md-10", "po-offset-lg-10", "po-offset-xl-10", 3, "p-disabled", "p-click"]], template: function FiltersCompareComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "po-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "po-accordion-item", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "po-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersCompareComponent_Template_po_select_ngModelChange_3_listener($event) { return ctx.filterService.selectedCountry = $event; })("p-change", function FiltersCompareComponent_Template_po_select_p_change_3_listener() { return ctx.getIdentifier(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "po-select", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersCompareComponent_Template_po_select_ngModelChange_4_listener($event) { return ctx.filterService.selectedIdentifier = $event; })("p-change", function FiltersCompareComponent_Template_po_select_p_change_4_listener() { return ctx.getRelease(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "po-select", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersCompareComponent_Template_po_select_ngModelChange_5_listener($event) { return ctx.filterService.selectedRelease = $event; })("p-change", function FiltersCompareComponent_Template_po_select_p_change_5_listener() { return ctx.getIdExecution(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "po-multiselect", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersCompareComponent_Template_po_multiselect_ngModelChange_6_listener($event) { return ctx.filterService.selectedIdExecution = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "po-checkbox", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersCompareComponent_Template_po_checkbox_ngModelChange_7_listener($event) { return ctx.filterService.lastExecution = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "po-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("p-click", function FiltersCompareComponent_Template_po_button_p_click_8_listener() { return ctx.filterService.addGrid(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "po-table", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "po-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("p-click", function FiltersCompareComponent_Template_po_button_p_click_11_listener() { return ctx.processData(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("p-options", ctx.country)("ngModel", ctx.filterService.selectedCountry);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.selectedIdentifier)("p-options", ctx.identifier);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.selectedRelease)("p-options", ctx.release);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.selectedIdExecution)("p-options", ctx.idExecution);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.lastExecution);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("p-columns", ctx.filterService.columnsGrid)("p-items", ctx.filterService.dataGrid);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("p-disabled", ctx.filterService.dataGrid.length == 0);
    } }, directives: [_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoAccordionComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoAccordionItemComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoMultiselectComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoCheckboxComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoButtonComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoTableComponent"]], encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FiltersCompareComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'filters-compare',
                templateUrl: './filters-compare.component.html',
            }]
    }], function () { return [{ type: _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_1__["FiltersFormService"] }, { type: _filters_compare_service__WEBPACK_IMPORTED_MODULE_2__["FiltersCompareService"] }, { type: _chart_chart_service__WEBPACK_IMPORTED_MODULE_3__["ChartService"] }]; }, { item1: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['item1', { static: true }]
        }] }); })();


/***/ }),

/***/ "./src/app/filters-compare/filters-compare.service.ts":
/*!************************************************************!*\
  !*** ./src/app/filters-compare/filters-compare.service.ts ***!
  \************************************************************/
/*! exports provided: FiltersCompareService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiltersCompareService", function() { return FiltersCompareService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _app_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app-config.service */ "./src/app/app-config.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");







class FiltersCompareService {
    constructor(_http, configService, poNotification) {
        this._http = _http;
        this.configService = configService;
        this.poNotification = poNotification;
        this.selectedCountry = 'BRA';
        this.lastExecution = false;
        this.filters = '';
        this.dataGrid = [];
        this.URL_API = this.configService.getConfig();
        this.columnsGrid = [
            { property: 'country', label: 'País', width: '24%' },
            { property: 'identifier', label: 'Identificador', width: '24%' },
            { property: 'release', label: 'Release', width: '25%' },
            { property: 'idExecution', label: 'ID Execução', width: '25%' },
            {
                property: 'lastExecution',
                label: 'Última Execução?',
                type: 'boolean',
                boolean: {
                    trueLabel: 'Sim',
                    falseLabel: 'Não',
                },
            },
            {
                property: 'delete',
                label: 'Ações',
                type: 'icon',
                icons: [
                    {
                        action: this.deleteRow.bind(this),
                        icon: 'po-icon-delete',
                        tooltip: 'Excluir',
                        value: 'delete',
                    },
                ],
            },
        ];
    }
    deleteRow(row) {
        this.dataGrid = this.dataGrid.filter((item) => item.country + item.identifier + item.release + item.idExecution !=
            row.country + row.identifier + row.release + row.idExecution);
    }
    getCountry() {
        return this._http.get(this.URL_API + 'country').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    getIdentifier(pais) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({ fromObject: { COUNTRY: pais } });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'identifier', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    getRelease(pais, identificador) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: { COUNTRY: pais, IDENTI: identificador },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'release', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    getIdExecution(country, identifier, release) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: { COUNTRY: country, IDENTI: identifier, RELEASE: release },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'idexecution', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    handleMessage(text, type) {
        switch (type) {
            case 1:
                this.poNotification.success(text);
                break;
            case 2:
                this.poNotification.information(text);
                break;
            default:
                this.poNotification.error(text);
                break;
        }
    }
    addGrid() {
        let duplicates = [];
        const countryGrid = this.selectedCountry;
        const identifierGrid = this.selectedIdentifier;
        const releaseGrid = this.selectedRelease;
        this.selectedIdExecution.forEach((execution) => {
            if (this.exists(execution)) {
                duplicates.push({
                    countryGrid,
                    identifierGrid,
                    releaseGrid,
                    execution,
                });
            }
            else {
                this.addRow(execution);
            }
        });
        if (duplicates.length > 0) {
            this.handleMessage('Já existe combinação inserida na grid para os parâmetros selecionados, por favor verifique os parâmetros.');
        }
    }
    exists(idExec) {
        return (this.dataGrid.filter((element) => element.country +
            element.identifier +
            element.release +
            element.idExecution ==
            this.selectedCountry +
                this.selectedIdentifier +
                this.selectedRelease +
                idExec).length > 0);
    }
    addRow(idExec) {
        this.dataGrid.push({
            country: this.selectedCountry,
            identifier: this.selectedIdentifier,
            release: this.selectedRelease,
            idExecution: idExec,
            delete: 'delete',
            lastExecution: this.lastExecution,
        });
    }
}
FiltersCompareService.ɵfac = function FiltersCompareService_Factory(t) { return new (t || FiltersCompareService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoNotificationService"])); };
FiltersCompareService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: FiltersCompareService, factory: FiltersCompareService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FiltersCompareService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"] }, { type: _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoNotificationService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/filters-form/filters-form.component.ts":
/*!********************************************************!*\
  !*** ./src/app/filters-form/filters-form.component.ts ***!
  \********************************************************/
/*! exports provided: FiltersFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiltersFormComponent", function() { return FiltersFormComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _filters_form_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./filters-form.service */ "./src/app/filters-form/filters-form.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");





const _c0 = ["item1"];
class FiltersFormComponent {
    constructor(filterService) {
        this.filterService = filterService;
        this.typeBlend = [
            { value: 'segmento', label: 'Segmento' },
            { value: 'squad', label: 'Squad' },
            { value: 'modulo', label: 'Módulo' },
            { value: 'criticidade', label: 'Critícidade' },
        ];
        this.segment = [];
        this.squad = [];
        this.module = [];
    }
    ngOnInit() {
        this.getSegment();
    }
    ngAfterContentInit() {
        this.item1.expand();
    }
    getSegment() {
        //-- Efetua carga no segmento
        this.filterService.getSegment().subscribe((response) => {
            this.segment = response;
        }, (error) => {
            console.log(error);
        });
    }
    getSquad() {
        this.filterService.selectedModule = [];
        this.filterService.selectedSquad = [];
        this.module = [];
        //-- Efetua carga no segmento
        if (this.filterService.selectedSegment.length > 0) {
            this.filterService
                .getSquad(this.filterService.selectedSegment)
                .subscribe((response) => {
                this.squad = response;
            });
        }
        else {
            this.squad = [];
            this.module = [];
        }
    }
    getModule() {
        this.filterService.selectedModule = [];
        //-- Efetua carga no segmento
        if (this.filterService.selectedSquad.length > 0) {
            this.filterService
                .getModule(this.filterService.selectedSegment, this.filterService.selectedSquad)
                .subscribe((response) => {
                this.module = response;
            });
        }
        else {
            this.module = [];
        }
    }
}
FiltersFormComponent.ɵfac = function FiltersFormComponent_Factory(t) { return new (t || FiltersFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_filters_form_service__WEBPACK_IMPORTED_MODULE_1__["FiltersFormService"])); };
FiltersFormComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FiltersFormComponent, selectors: [["filters-form"]], viewQuery: function FiltersFormComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstaticViewQuery"](_c0, true);
    } if (rf & 2) {
        var _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.item1 = _t.first);
    } }, decls: 8, vars: 8, consts: [["p-label", "Filtros"], ["item1", ""], ["name", "selectedTypeBlend", "p-label", "Tipo de Vis\u00E3o", 1, "po-md-3", 3, "p-options", "ngModel", "ngModelChange"], ["name", "selectedSegment", "p-placeholder", "Todos", "p-label", "Segmento", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["p-placeholder", "Todos", "name", "selectedSquad", "p-label", "Squad", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange", "p-change"], ["p-placeholder", "Todos", "name", "selectedModule", "p-label", "M\u00F3dulo", 1, "po-md-3", 3, "ngModel", "p-options", "ngModelChange"]], template: function FiltersFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "po-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "po-accordion-item", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "po-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersFormComponent_Template_po_select_ngModelChange_3_listener($event) { return ctx.filterService.selectedTypeBlend = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "po-multiselect", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersFormComponent_Template_po_multiselect_ngModelChange_4_listener($event) { return ctx.filterService.selectedSegment = $event; })("p-change", function FiltersFormComponent_Template_po_multiselect_p_change_4_listener() { return ctx.getSquad(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "po-multiselect", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersFormComponent_Template_po_multiselect_ngModelChange_5_listener($event) { return ctx.filterService.selectedSquad = $event; })("p-change", function FiltersFormComponent_Template_po_multiselect_p_change_5_listener() { return ctx.getModule(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "po-multiselect", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FiltersFormComponent_Template_po_multiselect_ngModelChange_6_listener($event) { return ctx.filterService.selectedModule = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("p-options", ctx.typeBlend)("ngModel", ctx.filterService.selectedTypeBlend);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.selectedSegment)("p-options", ctx.segment);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.selectedSquad)("p-options", ctx.squad);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.filterService.selectedModule)("p-options", ctx.module);
    } }, directives: [_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_2__["PoAccordionComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_2__["PoAccordionItemComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_2__["PoSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_2__["PoMultiselectComponent"]], encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FiltersFormComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'filters-form',
                templateUrl: './filters-form.component.html',
            }]
    }], function () { return [{ type: _filters_form_service__WEBPACK_IMPORTED_MODULE_1__["FiltersFormService"] }]; }, { item1: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"],
            args: ['item1', { static: true }]
        }] }); })();


/***/ }),

/***/ "./src/app/filters-form/filters-form.service.ts":
/*!******************************************************!*\
  !*** ./src/app/filters-form/filters-form.service.ts ***!
  \******************************************************/
/*! exports provided: FiltersFormService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiltersFormService", function() { return FiltersFormService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _app_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app-config.service */ "./src/app/app-config.service.ts");






class FiltersFormService {
    constructor(_http, configService) {
        this._http = _http;
        this.configService = configService;
        this.URL_API = this.configService.getConfig();
        //--Estado da aplicação
        this.isTotvs = false;
        this.selectedTypeBlend = 'segmento';
        this.selectedSegment = [];
        this.selectedSquad = [];
        this.selectedModule = [];
    }
    getSegment() {
        return this._http.get(this.URL_API + 'segment').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    getSquad(segments) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({ fromObject: { SEGMENT: segments } });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'squad', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
    getModule(segments, squad) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]({
            fromObject: { SEGMENT: segments, SQUAD: squad },
        });
        // Adiciona parametros de pesquisa
        const options = { params: params };
        return this._http.get(this.URL_API + 'module', options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])((res) => {
            return res;
        }));
    }
}
FiltersFormService.ɵfac = function FiltersFormService_Factory(t) { return new (t || FiltersFormService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"])); };
FiltersFormService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: FiltersFormService, factory: FiltersFormService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FiltersFormService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }, { type: _app_config_service__WEBPACK_IMPORTED_MODULE_3__["AppConfigService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _home_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.service */ "./src/app/home/home.service.ts");




class HomeComponent {
    constructor(homeService) {
        this.homeService = homeService;
    }
}
HomeComponent.ɵfac = function HomeComponent_Factory(t) { return new (t || HomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_home_service__WEBPACK_IMPORTED_MODULE_1__["HomeService"])); };
HomeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HomeComponent, selectors: [["ap-customer"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([_home_service__WEBPACK_IMPORTED_MODULE_1__["HomeService"]])], decls: 8, vars: 0, consts: [["src", "../../assets/images/RoboCor.png", "alt", "Imagem de Robo Preto"], [1, "po-font-display"]], template: function HomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "figure");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Bem vindo");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "ao");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Portal da Qualidade");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["figure[_ngcontent-%COMP%] {\r\n  text-align: center;\r\n}\r\n\r\nh1[_ngcontent-%COMP%] {\r\n  font-size: 50px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxlQUFlO0FBQ2pCIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJmaWd1cmUge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuaDEge1xyXG4gIGZvbnQtc2l6ZTogNTBweDtcclxufVxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HomeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'ap-customer',
                providers: [_home_service__WEBPACK_IMPORTED_MODULE_1__["HomeService"]],
                templateUrl: './home.component.html',
                styleUrls: ['./home.component.css'],
            }]
    }], function () { return [{ type: _home_service__WEBPACK_IMPORTED_MODULE_1__["HomeService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/home/home.service.ts":
/*!**************************************!*\
  !*** ./src/app/home/home.service.ts ***!
  \**************************************/
/*! exports provided: HomeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeService", function() { return HomeService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class HomeService {
}
HomeService.ɵfac = function HomeService_Factory(t) { return new (t || HomeService)(); };
HomeService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: HomeService, factory: HomeService.ɵfac });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HomeService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"]
    }], null, null); })();


/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @po-ui/ng-templates */ "./node_modules/@po-ui/ng-templates/__ivy_ngcc__/fesm2015/po-ui-ng-templates.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");







function LoginComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "po-loading-overlay");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class LoginComponent {
    constructor(router, instservice) {
        this.router = router;
        this.instservice = instservice;
        this.isLogged = false;
        this.loading = false;
    }
    ngOnInit() { }
    checkLogin(formData) {
        this.loading = true;
        this.instservice.userToken.username = formData.login;
        this.instservice.userToken.password = formData.password;
        this.instservice.userToken.token = '';
        /*this.instservice
          .getToken(
            this.instservice.userToken.username,
            this.instservice.userToken.password
          )
          .subscribe(
            (token) => {
              this.instservice.userToken.token = token;
              this.isLogged = true;
              this.router.navigate(['']);
            },
            (error) => {
              this.instservice.handleError(error);
              this.isLogged = false;
            }
          );*/
        this.instservice.userToken.token = this.instservice.getToken(this.instservice.userToken.username, this.instservice.userToken.password);
        this.isLogged = true;
        this.router.navigate(['']);
        setTimeout(() => {
            this.loading = false;
        }, 2000);
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 2, vars: 2, consts: [["p-hide-remember-user", "", "p-logo", "assets/images/totvs-logo-page-login.svg", 3, "p-loading", "p-login-submit"], ["class", "sample-container", 4, "ngIf"], [1, "sample-container"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "po-page-login", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("p-login-submit", function LoginComponent_Template_po_page_login_p_login_submit_0_listener($event) { return ctx.checkLogin($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, LoginComponent_div_1_Template, 2, 0, "div", 1);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("p-loading", ctx.loading);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.loading);
    } }, directives: [_po_ui_ng_templates__WEBPACK_IMPORTED_MODULE_3__["PoPageLoginComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_5__["PoLoadingOverlayComponent"]], encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-login',
                templateUrl: './login.component.html',
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }, { type: _app_service__WEBPACK_IMPORTED_MODULE_2__["AppService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/summary-chart-page/summary-chart-page.ts":
/*!**********************************************************!*\
  !*** ./src/app/summary-chart-page/summary-chart-page.ts ***!
  \**********************************************************/
/*! exports provided: SummaryChartPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SummaryChartPage", function() { return SummaryChartPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../filters-form/filters-form.service */ "./src/app/filters-form/filters-form.service.ts");
/* harmony import */ var _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../filters-compare/filters-compare.service */ "./src/app/filters-compare/filters-compare.service.ts");
/* harmony import */ var _chart_chart_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../chart/chart.service */ "./src/app/chart/chart.service.ts");
/* harmony import */ var _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @po-ui/ng-components */ "./node_modules/@po-ui/ng-components/__ivy_ngcc__/fesm2015/po-ui-ng-components.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _filters_compare_filters_compare_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../filters-compare/filters-compare.component */ "./src/app/filters-compare/filters-compare.component.ts");
/* harmony import */ var _filters_form_filters_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../filters-form/filters-form.component */ "./src/app/filters-form/filters-form.component.ts");
/* harmony import */ var _chart_chart_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../chart/chart.component */ "./src/app/chart/chart.component.ts");










function SummaryChartPage_filters_form_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "filters-form");
} }
function SummaryChartPage_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "app-chart");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class SummaryChartPage {
    constructor(filtersService, compareService, chartService) {
        this.filtersService = filtersService;
        this.compareService = compareService;
        this.chartService = chartService;
    }
    fieldsCleaner() {
        this.filtersService.selectedTypeBlend = 'segmento';
        this.filtersService.selectedSegment = [];
        this.filtersService.selectedSquad = [];
        this.filtersService.selectedModule = [];
        this.compareService.selectedCountry = 'BRA';
        this.compareService.selectedIdentifier = '';
        this.compareService.selectedRelease = '';
        this.compareService.selectedIdExecution = [];
        this.compareService.lastExecution = true;
        this.compareService.filters = '';
        this.compareService.dataGrid = [];
    }
}
SummaryChartPage.ɵfac = function SummaryChartPage_Factory(t) { return new (t || SummaryChartPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_1__["FiltersFormService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__["FiltersCompareService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_chart_chart_service__WEBPACK_IMPORTED_MODULE_3__["ChartService"])); };
SummaryChartPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SummaryChartPage, selectors: [["summary-chart-page"]], decls: 7, vars: 3, consts: [[3, "hidden"], ["p-title", "Comparar Testes"], [2, "text-align", "right", "cursor", "pointer"], [1, "po-icon", "po-icon-delete", 3, "click"], [4, "ngIf"]], template: function SummaryChartPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "po-loading-overlay", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "po-page-default", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SummaryChartPage_Template_span_click_3_listener() { return ctx.fieldsCleaner(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, SummaryChartPage_filters_form_4_Template, 1, 0, "filters-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "filters-compare");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, SummaryChartPage_div_6_Template, 2, 0, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", ctx.chartService.isHideLoading);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.filtersService.isTotvs);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.chartService.parametersFilter);
    } }, directives: [_po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoLoadingOverlayComponent"], _po_ui_ng_components__WEBPACK_IMPORTED_MODULE_4__["PoPageDefaultComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _filters_compare_filters_compare_component__WEBPACK_IMPORTED_MODULE_6__["FiltersCompareComponent"], _filters_form_filters_form_component__WEBPACK_IMPORTED_MODULE_7__["FiltersFormComponent"], _chart_chart_component__WEBPACK_IMPORTED_MODULE_8__["ChartComponent"]], encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SummaryChartPage, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'summary-chart-page',
                templateUrl: './summary-chart-page.html',
            }]
    }], function () { return [{ type: _filters_form_filters_form_service__WEBPACK_IMPORTED_MODULE_1__["FiltersFormService"] }, { type: _filters_compare_filters_compare_service__WEBPACK_IMPORTED_MODULE_2__["FiltersCompareService"] }, { type: _chart_chart_service__WEBPACK_IMPORTED_MODULE_3__["ChartService"] }]; }, null); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\company\servicelog-front\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map